"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var errorMiddleware = function (err, req, res, next) {
    res.status(err.status || 500);
    res.json({
        errors: {
            message: err.message,
        },
    });
};
exports.default = errorMiddleware;
//# sourceMappingURL=error.js.map