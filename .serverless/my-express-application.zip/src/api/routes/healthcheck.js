"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express_1 = require("express");
var package_json_1 = require("../../../package.json");
var route = express_1.Router();
exports.default = (function (app) {
    app.use('/healthcheck', route);
    route.get('/', function (req, res) {
        res.send(package_json_1.version);
    });
});
//# sourceMappingURL=healthcheck.js.map